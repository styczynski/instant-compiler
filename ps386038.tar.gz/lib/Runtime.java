public class Runtime {

    public static void printInt(int val) {
        System.out.println(""+val);
    }

}

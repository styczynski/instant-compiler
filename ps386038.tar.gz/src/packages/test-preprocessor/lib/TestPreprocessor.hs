module TestPreprocessor where

hyc :: String -> String
hyc x = x
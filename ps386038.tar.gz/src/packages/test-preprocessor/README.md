# test-preprocessor

This package provides utility to generate HSpecs suites from input Instant code.

## Usage

You can build the code with `stack build` and run it using the following command:
```bash
    $ stack exec test-preprocessor --help
```

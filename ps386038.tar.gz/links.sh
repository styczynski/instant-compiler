mkdir -p src/packages/parser/_build/parser
ln -f -s "$HOME/Development/bin/stack/stack" src/packages/parser/_build/parser/stack

ln -f -s "$HOME/Development/bin/stack/stack" src/packages/parser/stack
ln -f -s "$HOME/Development/bin/stack/stack" src/packages/core/stack
ln -f -s "$HOME/Development/bin/stack/stack" src/packages/cli-jvm/stack
ln -f -s "$HOME/Development/bin/stack/stack" src/packages/cli-llvm/stack
ln -f -s "$HOME/Development/bin/stack/stack" src/packages/stack
ln -f -s "$HOME/Development/bin/stack/stack" src/stack
ln -f -s "$HOME/Development/bin/stack/stack" stack

